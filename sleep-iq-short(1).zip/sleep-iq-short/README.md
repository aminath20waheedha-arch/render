# What If every sleep cost 10 IQ - 9:16 Short (1080x1920, 141.9 s)

Built with kelano86/what-if-animation (Remotion + SVG), vertical reframe of its 1920x1080 world.

## Render on your machine
    cd studio && npm install
    # delete the setBrowserExecutable('/tmp/chromium') and setConcurrency(1) lines in remotion.config.ts
    npx remotion render src/index.ts SleepIQ out/sleep-iq.mp4 --concurrency 4

Voice: studio/public/sleep-iq/voice.wav (your ElevenLabs file).
Timings: src/episodes/sleep-iq/words.json (aligned from the audio's pauses).
No SFX/music yet (no ElevenLabs key in my sandbox): use the repo's scripts/sfx.py, or add your own.
Edit shots: src/episodes/sleep-iq/shots1-3.tsx. Edit cuts: episode.json, then run the repo's plan.py sleep-iq.
