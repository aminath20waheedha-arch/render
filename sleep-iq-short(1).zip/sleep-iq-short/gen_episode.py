import json, sys
# (id, cue, size, set, key, note)
T = [
 ("S1","What","wide, high","bedroom",40,"title over the sleeping hero"),
 ("S2","lost","close-up","bedroom",34,"-10 floats up over the sleeper"),
 ("S3","The","schematic","schematic",50,"bell curve, 100 at the top"),
 ("S4","because","macro, top-down","tabletop",30,"the test paper fills in"),
 ("S5","tomorrow","medium","bedroom",40,"morning, he wakes at 100"),
 ("S7","But","close-up","bedroom",30,"one rule: the face goes worried"),
 ("S8","Every","schematic","schematic",90,"the number drops by 10"),
 ("S10","Night#2","medium","bedroom",90,"night one, wakes at 90"),
 ("S11","feel","medium","kitchen",20,"feels fine"),
 ("S12","leave","macro insert","fridge",30,"keys in the fridge"),
 ("S13","Night","medium","bedroom",80,"night two, wakes at 80"),
 ("S14","forget","medium","kitchen",50,"Mo and the cake, the smile falls"),
 ("S15","Night","medium","bedroom",45,"night three, wakes at 70"),
 ("S16","read","medium","study",25,"reading at the desk"),
 ("S17","four","macro, top-down","tabletop",30,"the page, four times"),
 ("S18","still","close-up","study",25,"dizzy"),
 ("S19","So","close-up","bedroom",30,"a decision"),
 ("S20","stop","wide","bedroom",30,"no sleep"),
]
extra = json.load(open('extra_shots.json')) if len(sys.argv)>1 and sys.argv[1]=='full' else []
T += [tuple(x) for x in extra]
ep = {
 "id":"SleepIQ","slug":"sleep-iq","topic":"What if every time you went to sleep, you lost 10 IQ points?",
 "title":["WHAT IF EVERY NIGHT YOU LOST","10 IQ POINTS?"],"accent":"10","power":"sleep tax",
 "script":[{"beat":"full script (user-supplied voice)","text":open('script.txt').read().replace('\n\n',' ').strip()}],
 "science":[
  {"claim":"After about 24 hours awake, performance is like a blood alcohol level of about 0.10%.","working":"Williamson & Feyer 2000 (Occup Environ Med): 17-19 h awake ~ 0.05% BAC; performance after 24 h ~ 0.10%.","source":"Williamson & Feyer, Occup Environ Med 2000;57:649-655"},
  {"claim":"In mice, the brain's clearance system is far more active in sleep (cited as almost 10x in the university release).","working":"Xie et al. 2013: tracer influx ~95% lower awake; interstitial space +60% in sleep; amyloid cleared ~2x faster. 'Almost 10-fold' is from the URMC press release, so the paper's own figures are lower.","source":"Xie et al., Science 2013;342:373; URMC news release 17 Oct 2013"},
  {"claim":"1964: a 17-year-old stayed awake 11 days, memory trouble from about day 3, then slept ~14 h and recovered.","working":"Gillin/Dement account of the 1964 case; 264 hours awake, 14 h 40 min recovery sleep.","source":"Dement, 'The Promise of Sleep'; Gulevich, Dement & Johnson 1966 (Arch Gen Psychiatry)"},
  {"claim":"The average IQ is 100 because tests are normed to a mean of 100 (SD 15).","working":"Standardisation of IQ scales.","source":"Wechsler scales manual"},
 ],
 "cast":["pipHood","mo","sis","suit"],
 "shots":[{"id":i,"size":s,"set":st,"key":k,"note":n} for (i,c,s,st,k,n) in T],
 "edit":[{"shot":i,"at":c} for (i,c,s,st,k,n) in T],
 "fx":[],
}
if not (len(sys.argv)>1 and sys.argv[1]=='full'): ep['end']='s:33.3'
else: ep['tail']=0.4
json.dump(ep,open('what-if-studio/src/episodes/sleep-iq/episode.json','w'),indent=1)
print(len(T),'shots')
