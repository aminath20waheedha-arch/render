import re, json, subprocess, numpy as np, wave
# envelope
subprocess.run(['ffmpeg','-v','error','-i','voice_in.wav','-ar','16000','-ac','1','v16.wav','-y'])
w=wave.open('v16.wav'); sr=w.getframerate(); x=np.frombuffer(w.readframes(w.getnframes()),dtype=np.int16).astype(float)/32768
hop=160; n=len(x)//hop
rms=np.sqrt((x[:n*hop].reshape(n,hop)**2).mean(1)); db=20*np.log10(rms+1e-9)
thr=db.max()-42
voiced=db>thr
# smooth: close tiny gaps <60ms
v=voiced.copy(); i=0
while i<n:
    if not v[i]:
        j=i
        while j<n and not v[j]: j+=1
        if j-i<6 and i>0 and j<n: v[i:j]=True
        i=j
    else: i+=1
# pauses >=0.14s inside speech
st=np.argmax(v); en=n-np.argmax(v[::-1])
pauses=[]; i=st
while i<en:
    if not v[i]:
        j=i
        while j<en and not v[j]: j+=1
        if j-i>=14: pauses.append((i/100,j/100))
        i=j
    else: i+=1
print("speech",st/100,en/100,"pauses",len(pauses)); json.dump(pauses,open("pauses.json","w"))
# voiced-time map
cum=np.concatenate([[0],np.cumsum(v)])/100.0
def vt(t): return cum[min(int(t*100),n)]
def real_hi(vtime):
    k=np.searchsorted(cum,vtime,side='right')-1; return min(max(k,0),n)/100.0
def real(vtime):
    k=np.searchsorted(cum,vtime); return min(k,n)/100.0
# tokens
text=open('script.txt').read()
toks=re.findall(r"[A-Za-z0-9'\.]+|[,\.\?!]",text)
words=[];bounds=[] # bounds: (index of word before, kind)
for t in re.finditer(r"[A-Za-z0-9']+(?:\.\d+)?|[,\.\?!]",text):
    s=t.group()
    if re.match(r"[A-Za-z0-9]",s): words.append({'w':s,'p':''})
    else:
        words[-1]['p']=s; bounds.append((len(words),s))  # boundary after len(words) words
wt=[max(2.2,len(x['w']))+ (1.5 if re.match(r'^\d',x['w']) else 0) for x in words]
cw=np.concatenate([[0],np.cumsum(wt)]); V=cum[en]-cum[st]
# predicted voiced pos for each boundary
pred=[cum[st]+cw[k]/cw[-1]*V for k,_ in bounds[:-1]]  # last is final
P=[(vt((a+b)/2),b-a,(a,b)) for a,b in pauses]
NB=len(pred); NP=len(P)
INF=1e9
skipc=lambda k:(3.0 if bounds[k][1] in '.?!' else 0.5)
D=np.full((NB+1,NP+1),INF); B={}
D[0,0]=0
for i in range(NB+1):
    for j in range(NP+1):
        if D[i,j]>=INF: continue
        c=D[i,j]
        if j<NP and i<NP+1:
            # unmatched pause
            if D[i,j+1]>c+0.15: D[i,j+1]=c+0.15; B[(i,j+1)]=(i,j,'p')
        if i<NB:
            if D[i+1,j]>c+skipc(i): D[i+1,j]=c+skipc(i); B[(i+1,j)]=(i,j,'s')
            if j<NP:
                d=abs(pred[i]-P[j][0]); cost=min(d,4)*0.9 - min(P[j][1],0.8)*1.5
                if D[i+1,j+1]>c+cost: D[i+1,j+1]=c+cost; B[(i+1,j+1)]=(i,j,'m')
# trace
i,j=NB,NP; match={}
while (i,j)!=(0,0):
    pi,pj,k=B[(i,j)]
    if k=='m': match[pi]=pj
    i,j=pi,pj
# anchors: word index boundaries -> real time
anch=[(0,st/100)]
for i,(k,_) in enumerate(bounds[:-1]):
    if i in match: a,b=pauses[match[i]]; anch.append((k,a,b))
out=[]; segs=[]
prev_k=0; prev_t=st/100
for item in anch[1:]+[(len(words),en/100,en/100)]:
    k,a,b=item
    segs.append((prev_k,k,prev_t,a)); prev_k=k; prev_t=b
for k0,k1,t0,t1 in segs:
    v0,v1=vt(t0),vt(t1); tot=sum(wt[k0:k1])
    acc=0
    for k in range(k0,k1):
        s=real_hi(v0+(acc/tot)*(v1-v0)); acc+=wt[k]; e=real(min(v0+(acc/tot)*(v1-v0),v1-1e-6))
        out.append({'w':words[k]['w'],'s':round(s,3),'e':round(e-0.02,3),'p':words[k]['p']})
json.dump(out,open('words.json','w'))
print(len(out),'words; matched',len(match),'of',NB)
# print sentence starts
sent=[0]+[k for k,p in bounds if p in '.?!']
for a,b in zip(sent[:-1],sent[1:]):
    print(f"{out[a]['s']:7.2f}-{out[b-1]['e']:7.2f}  "+' '.join(x['w'] for x in out[a:b])[:70])
