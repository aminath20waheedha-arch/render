import { Config } from '@remotion/cli/config';

Config.setVideoImageFormat('png');
Config.setOverwriteOutput(true);
Config.setEntryPoint('src/index.ts');
Config.setBrowserExecutable('/tmp/chromium');
Config.setChromiumOpenGlRenderer('swangle');
Config.setConcurrency(1);
