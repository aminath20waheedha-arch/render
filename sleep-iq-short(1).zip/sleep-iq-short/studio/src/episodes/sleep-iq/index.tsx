import { defineEpisode, Timeline } from '../../engine';
import timeline from './timeline.json';
import * as A from './shots1';
import * as B from './shots2';
import * as C from './shots3';

export const sleepIq = defineEpisode('SleepIQ', {
  timeline: timeline as Timeline,
  shots: { ...(A as any), ...(B as any), ...(C as any) },
  grain: false,
});
