import React from 'react';
import {
  Hero, Study, Desk, Schematic, DrawOn, SchLabel, Sparkle, Glow, LOOKS, LaptopBack, Bedroom, BedDuvet, bedSit, Rooftop, FloatLabel, Dial, Foreground,
} from '../../engine';
import { PIP, Sh, act, Brain, Zzz, Monitor, BigNum, Mono, WindowFG, kf, clamp, easeOut, rnd, ShotProps, Pose, FONT, Hud } from './common';

const SUIT = LOOKS.suit;
const SIS = LOOKS.sis;
const BS = bedSit(0.2);
const SB = { x: BS.x, y: BS.y, scale: BS.scale * 0.82 };
const at = (t: number, a: number, b: number) => clamp((t - a) / (b - a));
const face = (t: number, look: any, e: Pose['expr'], z = 3.3, bg = 'sA', extra?: React.ReactNode, glint = 0) => null;

const CloseUp: React.FC<{ t: number; len: number; f: number; id: string; look?: any; faces: [number, Pose['expr']][]; glint?: boolean; extra?: React.ReactNode; night?: boolean }> = ({ t, len, f, id, look = PIP, faces, glint, extra, night = true }) => {
  const pose = { ...act(t, { x: 960, y: 712, yaw: 0.15, headTilt: 0 }, [{ f: 20, p: { headTilt: -6 } }], faces), ...(glint ? { glint: at(t, 6, 14), glintColor: '#7FD4FF' } : {}) } as Pose;
  return (
    <Sh t={t} len={len} f={f} a={[960, 548, 3.2]} b={[960, 548, 3.7]}>
      <Study t={t + 330} id={id} night={night} />
      <Hero look={look} pose={pose} rimId="rimR" shadow={0} />
      <Desk x0={600} x1={1320} y={700} laptop={false} />
      {extra}
    </Sh>
  );
};

export const S41: React.FC<ShotProps> = (p) => <CloseUp {...p} id="s41" faces={[[0, 'worried']]} extra={<FloatLabel x={1110} y={430} t={p.t - 8} text="?" size={110} color="#FF8A3D" />} />;

// S42: DAY 11
export const S42: React.FC<ShotProps> = ({ t, len, f }) => {
  const pose = act(t, { x: 960, y: 712, yaw: 0.2, headTilt: 16, look: 0.2 }, [{ f: 40, p: { headTilt: 22 } }], [[0, 'tired']]);
  return (
    <Sh t={t} len={len} f={f} a={[960, 500, 1.3]} b={[960, 500, 1.45]} over={<g><Mono x={960} y={200} text="DAY" size={44} /><BigNum x={960} y={330} text="11" size={150} color="#FF5A5A" s={1 + 0.05 * Math.sin(t / 6)} /></g>}>
      <Study t={t + 360} id="s42" night veil={0.6} />
      <Hero look={PIP} pose={pose} rimId="rimR" shadow={0} />
      <Desk x0={600} x1={1320} y={700} />
    </Sh>
  );
};

// S43: the doctors give devastating news
export const S43: React.FC<ShotProps> = ({ t, len, f }) => {
  const pose = (x: number, yaw: number) => act(t, { x, y: 712, yaw, headTilt: 0 }, [{ f: 14, p: { headTilt: -5 } }], [[0, 'neutral'], [10, 'worried']]);
  return (
    <Sh t={t} len={len} f={f} a={[960, 580, 1.4]} b={[960, 575, 1.6]}>
      <Study t={t + 380} id="s43" veil={0.5} />
      <Hero look={SUIT} pose={pose(840, 0.35)} rimId="rimR" shadow={0} />
      <Hero look={SUIT} pose={pose(1090, -0.35)} rimId="rimR" shadow={0} />
    </Sh>
  );
};

// S44: sleep: 70 -> 60, but alive
export const S44: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[960, 540, 1.0]} b={[960, 540, 1.06]}>
    <Schematic t={t + 300} id="s44" />
    <Mono x={960} y={270} text="IF YOU SLEEP" size={44} />
    <BigNum x={960} y={560} text={t < 50 ? '70' : '60'} size={280} color={t < 50 ? '#FFB36B' : '#FF5A5A'} s={t >= 50 ? 1 + 0.25 * Math.sin(clamp((t - 50) / 14) * Math.PI) : 1} />
    <Monitor x={960} y={830} t={t} s={1.5} />
    <Mono x={960} y={970} text="YOU SURVIVE" size={40} color="#6BF2A0" o={at(t, 70, 80)} />
  </Sh>
);

// S45: awake: the brain shuts down
export const S45: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[960, 540, 1.0]} b={[960, 540, 1.08]}>
    <Schematic t={t + 330} id="s45" />
    <Mono x={960} y={260} text="IF YOU STAY AWAKE" size={42} />
    <Brain x={960} y={520} s={1.4} col="#F29AB0" dim={at(t, 20, 90)} glow={1 - at(t, 20, 90)} />
    <g opacity={at(t, 50, 80)}>
      <rect x={640} y={820} width={640} height={110} rx={12} fill="#10131C" stroke="#FF5A5A" strokeWidth={5} />
      <path d="M 670 875 H 1250" stroke="#FF5A5A" strokeWidth={6} />
    </g>
  </Sh>
);

// S46: Pip notices something on the screen
export const S46: React.FC<ShotProps> = ({ t, len, f }) => {
  const pose = { ...act(t, { x: 960, y: 712, yaw: 0, headTilt: 0 }, [], [[0, 'tired'], [14, 'shock']]), glint: at(t, 12, 20), glintColor: '#7FD4FF' } as Pose;
  return (
    <Sh t={t} len={len} f={f} a={[960, 610, 1.6]} b={[960, 600, 1.85]}>
      <Study t={t + 400} id="s46" night />
      <Hero look={PIP} pose={pose} rimId="rimR" shadow={0} />
      <Desk x0={600} x1={1320} y={700} laptop={false} />
      <LaptopBack x={1140} y={690} w={230} glow={1} />
    </Sh>
  );
};

// S47: the pattern
export const S47: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[960, 540, 1.0]} b={[960, 540, 1.1]}>
    <Schematic t={t + 360} id="s47" />
    {Array.from({ length: 6 }).flatMap((_, r) => Array.from({ length: 5 }).map((__, c) => {
      const lit = (r + c) % 2 === 0;
      const s = at(t, (r * 5 + c) * 0.8, (r * 5 + c) * 0.8 + 6);
      return <circle key={`${r}${c}`} cx={760 + c * 100} cy={380 + r * 100} r={26 * s} fill={lit ? '#FF8A3D' : '#7FD4FF'} />;
    }))}
    <DrawOn d="M 760 380 L 860 480 L 960 580 L 1060 680 L 1160 780" t={t - 24} dur={22} color="#FFE27A" width={7} />
    <Mono x={960} y={260} text="A PATTERN" size={48} color="#FFE27A" />
  </Sh>
);

// S48: across the world
export const S48: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[960, 640, 0.95]} b={[960, 620, 1.1]}>
    <Rooftop t={t + 40} sunX={1050} sunY={640} low={260} cityLit={1} />
    {[[760, 330, '70'], [1000, 280, '80'], [1180, 400, '60'], [880, 470, '90']].map(([x, y, n], i) => (
      <FloatLabel key={i} x={x as number} y={y as number} t={t - 6 - i * 7} text={`${n}`} size={70} color={i % 2 ? '#FFB36B' : '#FF5A5A'} />
    ))}
  </Sh>
);

// S49: including your younger sister
const Sister = (t: number, id: string, face: Pose['expr'], blink = 0) => {
  const pose = act(t, { x: SB.x, y: SB.y, scale: SB.scale, yaw: 0.15, blink, headTilt: blink ? 12 : 0 }, [], [[0, face]]);
  return (
    <>
      <Bedroom t={t + 420} id={id} duvet={false} crossed={0} clock="03:00" />
      <Hero look={SIS} pose={pose} rimId="rimR" shadow={0} />
      <BedDuvet />
    </>
  );
};
export const S49: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[SB.x + 20, SB.y - 70, 1.7]} b={[SB.x + 20, SB.y - 80, 1.95]}>
    {Sister(t, 'b49', 'tired', 1)}
    <Zzz x={SB.x + 70} y={SB.y - 200 * SB.scale} t={t} s={SB.scale * 1.7} />
    <FloatLabel x={SB.x + 150} y={SB.y - 330} t={t - 14} text="-10" size={90} color="#FF5A5A" />
  </Sh>
);

// S50: eureka
export const S50: React.FC<ShotProps> = (p) => <CloseUp {...p} id="s50" faces={[[0, 'neutral'], [8, 'happy']]} glint extra={<Sparkle x={1130} y={430} t={p.t - 10} s={1.1} />} />;

// S51: calculations not finished
export const S51: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[960, 540, 1.0]} b={[960, 540, 1.06]}>
    <Schematic t={t + 420} id="s51" />
    <Mono x={960} y={300} text="THE CURE" size={50} color="#6BF2A0" />
    <DrawOn d="M 700 420 q 40 -50 80 0 t 80 0 t 80 0 t 80 0" t={t} dur={24} color="#7FD4FF" width={6} />
    <DrawOn d="M 700 500 H 1100 M 700 560 H 1000 M 700 620 H 1180" t={t - 10} dur={30} color="#8FA0C8" width={5} />
    <rect x={700} y={760} width={520} height={50} rx={25} fill="#16172B" stroke="#8FA0C8" strokeWidth={4} />
    <rect x={704} y={764} width={512 * 0.87 * at(t, 10, 60)} height={42} rx={21} fill="#6BF2A0" />
    <Mono x={960} y={880} text="87%  ...NOT FINISHED" size={40} />
  </Sh>
);

// S52: a warning
export const S52: React.FC<ShotProps> = ({ t, len, f }) => {
  const pose = act(t, { x: 900, y: 712, yaw: 0.45, armR: { a: 20, b: -8 } }, [{ f: 8, p: { armR: { a: 100, b: 0 }, handR: 'point' }, ease: easeOut }], [[0, 'worried']]);
  return (
    <Sh t={t} len={len} f={f} a={[960, 600, 1.45]} b={[960, 595, 1.65]}>
      <Study t={t + 440} id="s52" veil={0.5} />
      <Hero look={SUIT} pose={{ ...pose, handR: t >= 8 ? 'point' : 'open' }} rimId="rimRed" shadow={0} />
    </Sh>
  );
};

// S53: ten minutes
export const S53: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[960, 540, 1.0]} b={[960, 540, 1.06]}>
    <Schematic t={t + 450} id="s53" />
    <Dial x={960} y={540} p={at(t, 0, 80)} readout="10:00" r={250} size={110} />
    <Mono x={960} y={250} text="STAY AWAKE FOR" size={42} />
  </Sh>
);

// S54: keep working
export const S54: React.FC<ShotProps> = ({ t, len, f }) => {
  const pose = { ...act(t, { x: 960, y: 712, yaw: 0.2, look: -0.4, armL: { a: 40, b: -70 }, armR: { a: 40, b: -70 } }, [{ f: 6, p: { armR: { a: 54, b: -80 } } }, { f: 12, p: { armL: { a: 52, b: -80 }, armR: { a: 40, b: -70 } } }, { f: 18, p: { armL: { a: 40, b: -70 } } }, { f: 24, p: { armR: { a: 54, b: -80 } } }], [[0, 'cool'], [30, 'tired']]), glint: 0.6, glintColor: '#7FD4FF' } as Pose;
  return (
    <Sh t={t} len={len} f={f} a={[960, 610, 1.3]} b={[960, 615, 1.6]}>
      <Study t={t + 470} id="s54" night />
      <Hero look={PIP} pose={pose} rimId="rimR" shadow={0} />
      <Desk x0={600} x1={1320} y={700} />
    </Sh>
  );
};

// S55: sleeping now: survive
export const S55: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[BS.x + 20, BS.y - 40, 1.5]} b={[BS.x + 20, BS.y - 60, 1.8]}>
    <Bedroom t={t + 500} id="b55" duvet={false} crossed={3} clock="03:00" />
    <Hero look={PIP} pose={act(t, { x: BS.x, y: BS.y, scale: BS.scale, yaw: 0.15, blink: 1, headTilt: 14 }, [], [[0, 'happy']])} rimId="rimR" shadow={0} />
    <BedDuvet />
    <Zzz x={BS.x + 80} y={BS.y - 200 * BS.scale} t={t} s={BS.scale * 1.6} />
  </Sh>
);

// S56: the cure is lost
export const S56: React.FC<ShotProps> = ({ t, len, f }) => {
  const g = at(t, 16, 40);
  return (
    <Sh t={t} len={len} f={f} a={[960, 540, 1.0]} b={[960, 540, 1.05]}>
      <Schematic t={t + 480} id="s56" />
      <Mono x={960} y={300} text="THE CURE" size={50} color="#6BF2A0" />
      <rect x={700} y={540} width={520} height={50} rx={25} fill="#16172B" stroke="#8FA0C8" strokeWidth={4} />
      <rect x={704} y={544} width={512 * 0.87 * (1 - g)} height={42} rx={21} fill="#6BF2A0" />
      <BigNum x={960} y={800} text="LOST" size={170} color="#FF5A5A" o={g} s={0.8 + 0.2 * g} />
    </Sh>
  );
};

// S57: through the hospital window
export const S57: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[SB.x + 40, SB.y - 20, 1.2]} b={[SB.x + 40, SB.y - 40, 1.4]}>
    {Sister(t, 'b57', 'happy', 1)}
    <Monitor x={SB.x + 260} y={SB.y - 120} t={t} s={0.6} />
    <Foreground blur={4}><WindowFG x={SB.x + 40} y={SB.y - 40} /></Foreground>
  </Sh>
);

// S58: your little sister, in bed
export const S58: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[SB.x + 90, SB.y - 80, 1.8]} b={[SB.x + 60, SB.y - 80, 2.0]}>
    {Sister(t, 'b58', 'tired', 1)}
    <Monitor x={SB.x + 270} y={SB.y - 160} t={t} s={0.7} />
  </Sh>
);

// S59: she smiles and whispers
export const S59: React.FC<ShotProps> = ({ t, len, f }) => {
  const h = { x: SB.x, y: SB.y - 150 * SB.scale };
  const pose = act(t, { x: SB.x, y: SB.y, scale: SB.scale, yaw: 0.15 }, [{ f: 14, p: { headTilt: 6 } }], [[0, 'neutral'], [8, 'happy']]);
  return (
    <Sh t={t} len={len} f={f} a={[h.x, h.y, 3.4]} b={[h.x, h.y - 4, 3.9]} over={<Mono x={960} y={930} text="are you going to be okay?" size={32} color="#FFFFFF" o={at(t, 24, 34)} />}>
      <Bedroom t={t + 520} id="b59" duvet={false} crossed={0} clock="03:00" />
      <Hero look={SIS} pose={pose} rimId="rimR" shadow={0} />
      <BedDuvet />
    </Sh>
  );
};

// S60: the timer starts
export const S60: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[960, 540, 1.0]} b={[960, 540, 1.1]}>
    <Schematic t={t + 520} id="s60" />
    <Dial x={960} y={540} p={at(t, 0, 30)} readout="10" r={250} size={170} />
  </Sh>
);

// ---------- the countdown, driven by the global clock so the digits land on the spoken numbers ----------
const CD: [number, number][] = [[125.9, 10], [127.2, 9], [128.17, 8], [129.0, 7], [129.65, 6], [130.26, 5], [132.2, 4], [133.73, 3], [134.61, 2], [135.37, 1]];
const cdAt = (f: number) => { let n = 10; for (const [s, v] of CD) if (f / 30 >= s - 0.05) n = v; return n; };
const CDNum: React.FC<{ f: number; y?: number; size?: number }> = ({ f, y = 270, size = 200 }) => {
  const n = cdAt(f);
  const s = f / 30;
  const t0 = CD.find((c) => c[1] === n)![0];
  const pop = 1 + 0.3 * Math.max(0, 1 - (s - t0) * 6);
  return <BigNum x={960} y={y} text={`${n}`} size={size} color={n <= 3 ? '#FF5A5A' : '#FFE27A'} s={pop} />;
};

type CDV = 'pip' | 'lap' | 'sis' | 'bed' | 'pip2' | 'dial';
const cdShot = (v: CDV, id: string): React.FC<ShotProps> => ({ t, len, f }) => {
  const sweat = Math.sin(t / 3) * 3;
  if (v === 'dial') {
    return (
      <Sh t={t} len={len} f={f} a={[960, 540, 1.0]} b={[960, 540, 1.1]} hud={false}>
        <Schematic t={t + 600} id={id} />
        <Dial x={960} y={540} p={1 - 0.04 * cdAt(f)} readout={`${cdAt(f)}`} r={260} size={190} />
      </Sh>
    );
  }
  if (v === 'sis') {
    const h = { x: SB.x, y: SB.y - 150 * SB.scale };
    return (
      <Sh t={t} len={len} f={f} a={[h.x, h.y, 3.0]} b={[h.x, h.y, 3.5]} hud={false} over={<CDNum f={f} />}>
        <Bedroom t={t + 530} id={id} duvet={false} crossed={0} clock="03:00" />
        <Hero look={SIS} pose={act(t, { x: SB.x, y: SB.y, scale: SB.scale, yaw: 0.15 }, [], [[0, 'happy']])} rimId="rimR" shadow={0} />
        <BedDuvet />
      </Sh>
    );
  }
  if (v === 'bed') {
    return (
      <Sh t={t} len={len} f={f} a={[BS.x + 20, BS.y - 40, 1.5]} b={[BS.x + 20, BS.y - 50, 1.75]} hud={false} over={<CDNum f={f} />}>
        <Bedroom t={t + 540} id={id} duvet={false} crossed={3} clock="03:00" />
        <Hero look={PIP} pose={act(t, { x: BS.x, y: BS.y, scale: BS.scale, yaw: 0.15, blink: 1, headTilt: 14 }, [], [[0, 'tired']])} rimId="rimR" shadow={0} />
        <BedDuvet />
        <Zzz x={BS.x + 80} y={BS.y - 200 * BS.scale} t={t} s={BS.scale * 1.6} />
      </Sh>
    );
  }
  if (v === 'lap') {
    return (
      <Sh t={t} len={len} f={f} a={[960, 640, 1.5]} b={[960, 640, 1.75]} hud={false} over={<CDNum f={f} />}>
        <Study t={t + 550} id={id} night />
        <Desk x0={600} x1={1320} y={700} laptop={false} />
        <LaptopBack x={960} y={690} w={360} glow={1} />
        <Mono x={960} y={560} text="CURE 87%" size={26} color="#6BF2A0" />
      </Sh>
    );
  }
  const pose = { ...act(t, { x: 960 + sweat, y: 712, yaw: 0.1, headTilt: sweat }, [], [[0, v === 'pip' ? 'worried' : 'shock']]), glint: 0 } as Pose;
  return (
    <Sh t={t} len={len} f={f} a={[960, 548, 3.0]} b={[960, 548, 3.5]} hud={false} over={<CDNum f={f} />}>
      <Study t={t + 560} id={id} night veil={0.6} />
      <Hero look={PIP} pose={pose} rimId="rimRed" shadow={0} />
      <Desk x0={600} x1={1320} y={700} laptop={false} />
    </Sh>
  );
};
export const S61 = cdShot('pip', 'c61');
export const S62 = cdShot('lap', 'c62');
export const S63 = cdShot('sis', 'c63');
export const S64 = cdShot('bed', 'c64');
export const S65 = cdShot('pip2', 'c65');
export const S66 = cdShot('lap', 'c66');
export const S67 = cdShot('sis', 'c67');
export const S68 = cdShot('pip', 'c68');
export const S69 = cdShot('dial', 'c69');

// S70: the choice, split: sleep above, the cure below
export const S70: React.FC<ShotProps> = ({ t, len, f }) => {
  const sweat = Math.sin(t / 4) * 2;
  return (
    <Sh t={t} len={len} f={f} a={[960, 540, 1.0]} hud={false}>
      <defs>
        <clipPath id="cTop"><rect x={656} y={0} width={608} height={534} /></clipPath>
        <clipPath id="cBot"><rect x={656} y={546} width={608} height={534} /></clipPath>
      </defs>
      <g clipPath="url(#cTop)">
        <g transform="translate(960 300) scale(1.25) translate(-690 -520)">
          <Bedroom t={t + 600} id="b70" duvet={false} crossed={3} clock="03:00" />
          <Hero look={PIP} pose={act(t, { x: BS.x, y: BS.y, scale: BS.scale, yaw: 0.15, blink: 1, headTilt: 14 }, [], [[0, 'happy']])} rimId="rimR" shadow={0} />
          <BedDuvet />
        </g>
        <rect x={656} y={0} width={608} height={534} fill="#4A6FE0" opacity={0.12} />
      </g>
      <g clipPath="url(#cBot)">
        <g transform="translate(960 810) scale(1.3) translate(-960 -640)">
          <Study t={t + 610} id="s70" night />
          <Desk x0={600} x1={1320} y={700} laptop={false} />
          <LaptopBack x={960} y={690} w={340} glow={1} />
        </g>
        <rect x={656} y={546} width={608} height={534} fill="#FF8A3D" opacity={0.1} />
      </g>
      <rect x={656} y={534} width={608} height={12} fill="#0E0C1E" />
      <BigNum x={960} y={110} text="SLEEP" size={84} color="#CFE0FF" />
      <Mono x={960} y={160} text="and survive" size={30} color="#CFE0FF" />
      <BigNum x={960} y={1010} text="STAY AWAKE" size={66} color="#FFB36B" />
      <Mono x={960} y={1056} text="finish the cure" size={28} color="#FFB36B" />
    </Sh>
  );
};

// S71: What would you choose?
export const S71: React.FC<ShotProps> = ({ t, len, f }) => {
  const pose = act(t, { x: 960, y: 712, yaw: 0.1, headTilt: 0 }, [{ f: 20, p: { headTilt: -6 } }], [[0, 'worried']]);
  const pop = (d: number) => clamp((t - d) / 8);
  return (
    <Sh t={t} len={len} f={f} a={[960, 580, 1.6]} b={[960, 570, 1.8]} hud={false}
      over={<g>
        <g transform={`translate(960 210) scale(${pop(2)})`}><text textAnchor="middle" fontFamily={FONT.title} fontWeight={700} fontSize={64} fill="#F6EFE3" stroke="#1A1230" strokeWidth={9} paintOrder="stroke">WHAT WOULD</text></g>
        <g transform={`translate(960 320) scale(${pop(8)})`}><text textAnchor="middle" fontFamily={FONT.title} fontWeight={800} fontSize={78} fill="#FFE27A" stroke="#1A1230" strokeWidth={10} paintOrder="stroke">YOU CHOOSE?</text></g>
      </g>}>
      <Study t={t + 640} id="s71" night veil={0.6} />
      <Hero look={PIP} pose={pose} rimId="rimR" shadow={0} />
      <Desk x0={600} x1={1320} y={700} laptop={false} />
    </Sh>
  );
};
