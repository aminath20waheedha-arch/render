import React from 'react';
import {
  Bedroom, BedDuvet, bedSit, BEDROOM, stand, Kitchen, KitchenIsland, KITCHEN, islandTop, Study, Desk, Schematic, DrawOn, Arrow, SchLabel, CountUp,
  Hero, Tabletop, Paper, OpenBook, Mug, Plate, Foreground, FloatLabel, DizzyStars, Sparkle, Tag, LOOKS, LightVeil, Glow, FocusRings, HEAD, LEG_LEN,
} from '../../engine';
import { PIP, Sh, act, VTitle, Cake, Keys, Zzz, BigNum, Mono, kf, clamp, easeOut, backOut, ShotProps, Pose, lin } from './common';

const MO = LOOKS.mo;
const BS = bedSit(0.2);
const bedBase = { x: BS.x, y: BS.y, scale: BS.scale, yaw: 0.15 };
const headOf = (p: { x: number; y: number; scale: number }) => ({ x: p.x, y: p.y - 150 * p.scale });
const clockStr = (t: number, wake: number, a = '02:13', b = '07:00') => (t < wake ? a : b);

// A sleeper, upright against the pillows with the duvet over the legs, wakes at frame `wake`.
const SleepPose = (t: number, wake: number, face: Pose['expr'] = 'happy'): Pose =>
  act(t, { ...bedBase, blink: 1, headTilt: 14, armL: { a: 8, b: -4 }, armR: { a: 8, b: -4 } }, [
    { f: wake - 4, p: { blink: 1, headTilt: 14 } },
    { f: wake + 3, p: { blink: 0, headTilt: 0 }, ease: easeOut },
    { f: wake + 12, p: { armL: { a: 168, b: -8 }, armR: { a: 168, b: -8 } }, ease: easeOut },
    { f: wake + 34, p: { armL: { a: 30, b: -10 }, armR: { a: 30, b: -10 } } },
  ], [[0, 'tired'], [wake + 3, face]]);

const BedScene: React.FC<{ t: number; id: string; crossed: number; wake: number; clock?: string; face?: Pose['expr']; lamp?: number }> = ({ t, id, crossed, wake, clock, face, lamp = 1 }) => (
  <>
    <Bedroom t={t + 60} id={id} duvet={false} crossed={crossed} clock={clock ?? clockStr(t, wake)} lamp={lamp} />
    <Hero look={PIP} pose={SleepPose(t, wake, face)} rimId="rimR" shadow={0} />
    <BedDuvet />
    {t < wake ? <Zzz x={BS.x + 80} y={BS.y - 200 * BS.scale} t={t} s={BS.scale * 1.6} /> : null}
  </>
);

// S1: wide, the title over a sleeping Pip
export const S1: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[760, 440, 0.95]} b={[740, 470, 1.1]} over={<VTitle t={t} />}>
    <BedScene t={t} id="b1" crossed={0} wake={999} clock="23:59" />
  </Sh>
);

// S2: close-up on the sleeper, -10 floats up
export const S2: React.FC<ShotProps> = ({ t, len, f }) => {
  const h = headOf(BS);
  return (
    <Sh t={t} len={len} f={f} a={[h.x, h.y + 10, 3.4]} b={[h.x, h.y, 3.8]} over={<g><FloatLabel x={960} y={820} t={t - 14} text="-10" color="#FF5A5A" size={170} /></g>}>
      <BedScene t={t} id="b2" crossed={0} wake={999} clock="23:59" />
    </Sh>
  );
};

// S3: the bell curve, 100 at the top
export const S3: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[960, 540, 1.0]} b={[960, 520, 1.08]}>
    <Schematic t={t + 10} id="s3" />
    <DrawOn d="M 620 800 H 1300" t={t} dur={10} color="#8FA0C8" width={5} />
    <DrawOn d="M 640 800 C 770 800 830 430 960 430 C 1090 430 1150 800 1280 800" t={t} dur={26} color="#7FD4FF" width={9} />
    <DrawOn d="M 960 430 V 800" t={t - 20} dur={10} color="#FFE27A" width={5} />
    <SchLabel x={960} y={350} t={t - 12} text="AVERAGE" size={44} color="#F6EFE3" />
    <CountUp x={960} y={940} t={t - 8} to={100} dur={22} size={170} color="#FFE27A" />
  </Sh>
);

// S4: a test paper, filled in
export const S4: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[960, 520, 1.0]} b={[960, 540, 1.12]}>
    <Tabletop edge={1000} wood="#7A5C42" grain="#6A4C36" lip="#5E4430" floor="#2A2230" floorLines="#201A26" />
    <LightVeil id="s4v" lights={[[960, 480, 520]]} o={0.5} />
    <Glow x={960} y={440} r={520} o={0.3} />
    <Paper x={960} y={520} w={420} rot={-5} done grade="100" fill={clamp(t / 40)} />
    <rect x={1130} y={700} width={190} height={22} rx={6} fill="#E9C46A" transform="rotate(-24 1130 700)" />
  </Sh>
);

// S5: morning, Pip wakes at 100
export const S5: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[BS.x + 10, BS.y - 60, 1.75]} b={[BS.x + 10, BS.y - 70, 1.95]}>
    <BedScene t={t} id="b5" crossed={0} wake={16} clock={clockStr(t, 16, '06:59', '07:00')} />
    {t > 30 ? <Sparkle x={BS.x + 90} y={BS.y - 280 * BS.scale} t={t - 30} s={1.2} /> : null}
  </Sh>
);

// S7: close-up, the face goes worried: there's a rule
export const S7: React.FC<ShotProps> = ({ t, len, f }) => {
  const h = headOf(BS);
  const pose = act(t, { ...bedBase, headTilt: 0 }, [{ f: 18, p: { headTilt: -6 } }], [[0, 'neutral'], [14, 'worried']]);
  return (
    <Sh t={t} len={len} f={f} a={[h.x, h.y, 3.2]} b={[h.x + 6, h.y, 3.7]}>
      <Bedroom t={t + 200} id="b7" duvet={false} crossed={0} clock="07:00" />
      <Hero look={PIP} pose={pose} rimId="rimR" shadow={0} />
      <BedDuvet />
    </Sh>
  );
};

// S8: the rule on the schematic: the number drops by 10
export const S8: React.FC<ShotProps> = ({ t, len, f }) => {
  const dropped = t >= 66;
  const pop = dropped ? 1 + 0.3 * Math.sin(clamp((t - 66) / 14) * Math.PI) : 1;
  return (
    <Sh t={t} len={len} f={f} a={[960, 540, 1.0]} b={[960, 540, 1.06]}>
      <Schematic t={t + 40} id="s8" />
      <circle cx={960} cy={290} r={78} fill="#E9E3C8" />
      <circle cx={1000} cy={268} r={70} fill="#16172B" />
      <Mono x={960} y={430} text="EVERY NIGHT" size={40} />
      <BigNum x={960} y={720} text={dropped ? '90' : '100'} size={260} color={dropped ? '#FF5A5A' : '#FFE27A'} s={pop} />
      <Arrow x0={960} y0={790} x1={960} y1={930} t={t - 50} dur={12} color="#FF5A5A" />
      <SchLabel x={960} y={1000} t={t - 56} text="-10" size={72} color="#FF5A5A" />
    </Sh>
  );
};

// S10: night one: asleep, then 90
export const S10: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[BS.x + 10, BS.y - 40, 1.5]} b={[BS.x + 10, BS.y - 60, 1.85]}>
    <BedScene t={t} id="b10" crossed={1} wake={55} clock={clockStr(t, 55, '03:41', '07:00')} />
  </Sh>
);

// S11: "you feel fine": the kitchen, Pip with a mug
const KS = stand(KITCHEN, 0.42, 0.4);
const KI = islandTop(0.62, 0.45);
export const S11: React.FC<ShotProps> = ({ t, len, f }) => {
  const pose = act(t, { x: KS.x, y: KS.y, scale: KS.scale, yaw: 0.5, look: 0.8, armL: { a: 12, b: -8 } }, [{ f: 8, p: { armR: { a: 30, b: -70 } }, ease: easeOut }], [[0, 'happy']]);
  return (
    <Sh t={t} len={len} f={f} a={[KS.x + 40, 610, 1.85]} b={[KS.x + 50, 610, 2.0]}>
      <Kitchen t={t + 40} id="k11" />
      <Hero look={PIP} pose={pose} rimId="rimR" shadow={0} />
      <KitchenIsland />
      <Mug x={KI.x} y={KI.y - 6} rot={0} f={t} />
      <Foreground blur={10}>
        <path d="M 1260 1000 Q 1300 760 1420 700 Q 1380 820 1400 1000 Z" fill="#0E1610" />
      </Foreground>
    </Sh>
  );
};

// S12: the keys, in the fridge
export const S12: React.FC<ShotProps> = ({ t, len, f }) => {
  const door = clamp(t / 10);
  return (
    <Sh t={t} len={len} f={f} a={[960, 540, 1.0]} b={[960, 540, 1.12]}>
      <rect x={560} y={-40} width={800} height={1160} fill="#10121C" />
      <rect x={620} y={60} width={680} height={960} rx={24} fill="#D9ECF5" />
      <rect x={620} y={60} width={680} height={960} rx={24} fill="url(#none)" />
      {[330, 590, 850].map((y) => <rect key={y} x={640} y={y} width={640} height={14} fill="#9FB8C6" />)}
      {/* shelf 1: milk and eggs; shelf 2: the keys; shelf 3: jars */}
      <rect x={700} y={160} width={110} height={170} rx={8} fill="#F6F4EE" /><rect x={700} y={160} width={110} height={40} fill="#6FA8DC" />
      {[0, 1, 2, 3].map((i) => <ellipse key={i} cx={960 + i * 62} cy={300} rx={28} ry={34} fill="#F3E3C8" />)}
      <g transform={`translate(0 ${(1 - easeOut(clamp((t - 6) / 10))) * -60})`}>
        <Keys x={880} y={500} s={1.5} rot={-12} />
      </g>
      {[0, 1, 2].map((i) => <rect key={i} x={700 + i * 170} y={720} width={120} height={130} rx={14} fill={['#D98BA0', '#E9C46A', '#8FBF7A'][i]} />)}
      <Glow x={960} y={420} r={700} o={0.25} />
      <FocusRings x={960} y={520} t={t - 12} r0={60} />
      <FloatLabel x={1180} y={440} t={t - 14} text="?!" size={130} color="#FF8A3D" />
    </Sh>
  );
};

// S13: night two, then 80
export const S13: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[BS.x + 10, BS.y - 40, 1.5]} b={[BS.x + 10, BS.y - 60, 1.85]}>
    <BedScene t={t} id="b13" crossed={2} wake={46} clock={clockStr(t, 46, '03:12', '07:00')} />
  </Sh>
);

// S14: Mo with a birthday cake; the smile falls at "birthday"
const MS = stand(KITCHEN, 0.5, 0.4);
export const S14: React.FC<ShotProps> = ({ t, len, f }) => {
  const pose = act(t, { x: MS.x, y: MS.y, scale: MS.scale, yaw: 0.1, look: 0, armL: { a: 20, b: -30 }, armR: { a: 20, b: -30 } }, [], [[0, 'happy'], [34, 'worried']]);
  const ci = islandTop(0.5, 0.45);
  return (
    <Sh t={t} len={len} f={f} a={[MS.x, 600, 1.8]} b={[MS.x, 600, 1.95]}>
      <Kitchen t={t + 90} id="k14" />
      <Hero look={MO} pose={pose} rimId="rimR" shadow={0} />
      <KitchenIsland />
      <Cake x={ci.x} y={ci.y + 4} s={0.7} flame={t / 3} />
      <Foreground blur={10}>
        <path d="M 600 1000 Q 640 740 760 700 Q 700 840 720 1000 Z" fill="#0E1610" />
      </Foreground>
    </Sh>
  );
};

// S15: night three, then 70
export const S15: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[BS.x + 10, BS.y - 40, 1.5]} b={[BS.x + 10, BS.y - 60, 1.85]}>
    <BedScene t={t} id="b15" crossed={3} wake={28} clock={clockStr(t, 28, '03:50', '07:00')} face="worried" />
  </Sh>
);

// S16: the study desk, Pip reads
export const S16: React.FC<ShotProps> = ({ t, len, f }) => {
  const pose = act(t, { x: 960, y: 712, yaw: 0.3, look: -0.6, armL: { a: 38, b: -60 }, armR: { a: 38, b: -60 }, headTilt: 8 }, [{ f: 30, p: { headTilt: 14 } }], [[0, 'neutral'], [30, 'worried']]);
  return (
    <Sh t={t} len={len} f={f} a={[960, 610, 1.75]} b={[960, 620, 1.9]}>
      <Study t={t + 80} id="s16" />
      <Hero look={PIP} pose={pose} rimId="rimR" shadow={0} />
      <Desk x0={600} x1={1320} y={700} laptop={false} />
      <OpenBook x={960} y={690} w={230} />
    </Sh>
  );
};

// S17: the page, four times
export const S17: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[960, 540, 1.0]} b={[960, 530, 1.1]}>
    <Tabletop edge={1000} wood="#7A5C42" grain="#6A4C36" lip="#5E4430" floor="#2A2230" floorLines="#201A26" />
    <LightVeil id="s17v" lights={[[960, 500, 560]]} o={0.5} />
    <Glow x={960} y={430} r={520} o={0.3} />
    <OpenBook x={960} y={540} w={560} turn={clamp(((t % 15) - 2) / 10)} />
    {[0, 1, 2, 3].map((i) => <FloatLabel key={i} x={780 + i * 120} y={330} t={t - 12 - i * 8} text="?" size={90} color="#FF8A3D" />)}
  </Sh>
);

// S18: dizzy close-up
export const S18: React.FC<ShotProps> = ({ t, len, f }) => {
  const pose = act(t, { x: 960, y: 712, yaw: 0.2, look: 0, headTilt: 0 }, [{ f: 16, p: { headTilt: 10 } }, { f: 34, p: { headTilt: -10 } }], [[0, 'worried'], [10, 'dizzy']]);
  return (
    <Sh t={t} len={len} f={f} a={[960, 548, 3.3]} b={[960, 548, 3.7]}>
      <Study t={t + 150} id="s18" />
      <Hero look={PIP} pose={pose} rimId="rimR" shadow={0} />
      <Desk x0={600} x1={1320} y={700} laptop={false} />
      <g transform="translate(960 470) scale(0.45) translate(-960 -470)"><DizzyStars x={960} y={470} t={t} /></g>
    </Sh>
  );
};

// S19: "you make a decision": determined
export const S19: React.FC<ShotProps> = ({ t, len, f }) => {
  const pose = act(t, { x: BS.x, y: BS.y, scale: BS.scale, yaw: 0.1, headTilt: 0 }, [{ f: 14, p: { headTilt: -4 } }], [[0, 'neutral'], [12, 'cool']]);
  const h = headOf(BS);
  return (
    <Sh t={t} len={len} f={f} a={[h.x, h.y, 3.3]} b={[h.x, h.y - 4, 3.9]}>
      <Bedroom t={t + 300} id="b19" duvet={false} crossed={3} clock="03:00" />
      <Hero look={PIP} pose={{ ...pose, glasses: clamp((t - 12) / 8) }} rimId="rimR" shadow={0} />
      <BedDuvet />
    </Sh>
  );
};

// S20: "you stop sleeping": Pip beside the made bed
const NS = stand(BEDROOM, 0.62, 0.3);
export const S20: React.FC<ShotProps> = ({ t, len, f }) => {
  const pose = act(t, { x: NS.x, y: NS.y, scale: NS.scale, yaw: -0.55, look: -0.8, armR: { a: 20, b: -8 }, armL: { a: 12, b: -8 } }, [
    { f: 6, p: { armL: { a: 95, b: 0 }, handL: 'point' }, ease: easeOut },
  ], [[0, 'cool']]);
  return (
    <Sh t={t} len={len} f={f} a={[NS.x - 70, 560, 1.0]} b={[NS.x - 60, 560, 1.12]}>
      <Bedroom t={t + 340} id="b20" crossed={3} clock="03:00" />
      <Hero look={PIP} pose={{ ...pose, handL: t >= 6 ? 'point' : 'open' }} rimId="rimR" shadow={0} />
      <Tag x={NS.x + 30} y={NS.y - 330 * NS.scale} t={t - 8} text="NO SLEEP" mark="x" markT={10} w={230} />
    </Sh>
  );
};
