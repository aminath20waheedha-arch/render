import React from 'react';
import {
  Hero, Study, Desk, Schematic, DrawOn, Arrow, SchLabel, CountUp, Tabletop, Paper, FloatLabel, DizzyStars, Sparkle, Tag, LOOKS, LightVeil, Glow,
  AlarmClock, LaptopBack, Bedroom, BedDuvet, bedSit, Foreground, FocusRings, Dial,
} from '../../engine';
import { PIP, Sh, act, Cake, Keys, Can, Brain, Mouse, Zzz, Monitor, BigNum, Mono, kf, clamp, easeOut, backOut, rnd, ShotProps, Pose, FONT } from './common';

const SUIT = LOOKS.suit;
const BS = bedSit(0.2);
const at = (t: number, a: number, b: number) => clamp((t - a) / (b - a));

// S21: "for a while, it works": Pip typing at the desk
export const S21: React.FC<ShotProps> = ({ t, len, f }) => {
  const pose = act(t, { x: 960, y: 712, yaw: 0.25, look: -0.5, armL: { a: 40, b: -70 }, armR: { a: 40, b: -70 } }, [
    { f: 8, p: { armR: { a: 52, b: -80 } } }, { f: 16, p: { armR: { a: 40, b: -70 }, armL: { a: 50, b: -78 } } }, { f: 24, p: { armL: { a: 40, b: -70 } } }, { f: 32, p: { armR: { a: 52, b: -80 } } },
  ], [[0, 'happy']]);
  return (
    <Sh t={t} len={len} f={f} a={[960, 610, 1.3]} b={[960, 620, 1.55]}>
      <Study t={t + 60} id="s21" night />
      <Hero look={PIP} pose={pose} rimId="rimR" shadow={0} />
      <Desk x0={600} x1={1320} y={700} />
    </Sh>
  );
};

// S22: energy drinks (and loud music) on the desk
export const S22: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[960, 560, 1.05]} b={[960, 540, 1.2]}>
    <Tabletop edge={1000} wood="#5A4A62" grain="#4A3C52" lip="#3E3248" floor="#241E30" floorLines="#1C1826" />
    <LightVeil id="s22v" lights={[[960, 520, 560]]} o={0.5} />
    <Glow x={960} y={460} r={520} o={0.3} />
    {[[800, 720, '#46C28A', -8], [960, 760, '#FF5A8A', 4], [1120, 710, '#46A2FF', 10]].map(([x, y, c, r], i) => (
      <g key={i} transform={`translate(0 ${(1 - backOut(at(t, 4 + i * 6, 14 + i * 6))) * -300})`}><Can x={x as number} y={y as number} s={2.2} col={c as string} tilt={r as number} /></g>
    ))}
    {[0, 1, 2, 3, 4].map((i) => <FloatLabel key={i} x={700 + i * 110} y={420} t={t - 20 - i * 6} text={i % 2 ? '♪' : '♫'} size={80} color="#7FD4FF" />)}
  </Sh>
);

// S24: the number holds at 70
export const S24: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[960, 540, 1.0]} b={[960, 540, 1.07]}>
    <Schematic t={t + 70} id="s24" />
    <BigNum x={960} y={640} text="70" size={300} color="#FFB36B" s={1 + 0.04 * Math.sin(t / 5)} />
    <DrawOn d="M 800 820 L 920 930 L 1160 740" t={t - 12} dur={12} color="#6BF2A0" width={22} />
    <Mono x={960} y={330} text="HOLDING" size={46} />
  </Sh>
);

// S25: 24 hours awake: the clock
export const S25: React.FC<ShotProps> = ({ t, len, f }) => {
  const hrs = Math.min(24, Math.floor(at(t, 0, 50) * 24));
  const pose = act(t, { x: 960, y: 712, yaw: 0.3, look: 0.4, headTilt: 0 }, [{ f: 40, p: { headTilt: 12 } }], [[0, 'tired']]);
  return (
    <Sh t={t} len={len} f={f} a={[1010, 580, 1.6]} b={[1000, 570, 1.85]}>
      <Study t={t + 90} id="s25" night />
      <Hero look={PIP} pose={pose} rimId="rimR" shadow={0} />
      <Desk x0={600} x1={1320} y={700} />
      <AlarmClock x={1085} y={655} s={0.8} text={`${String(hrs).padStart(2, '0')}:00`} />
    </Sh>
  );
};

// S26: the brain like it's drunk: Pip sways
export const S26: React.FC<ShotProps> = ({ t, len, f }) => {
  const sway = Math.sin(t / 9) * 8;
  const pose = act(t, { x: 960 + sway * 3, y: 712, yaw: 0.2, tilt: sway, headTilt: sway * 1.6, look: Math.sin(t / 11) }, [], [[0, 'dizzy']]);
  return (
    <Sh t={t} len={len} f={f} a={[960, 590, 1.7]} b={[960, 580, 1.95]}>
      <Study t={t + 120} id="s26" night />
      <Hero look={PIP} pose={pose} rimId="rimR" shadow={0} />
      <Desk x0={600} x1={1320} y={700} laptop={false} />
      <g transform="scale(0.5)" style={{ transformOrigin: '960px 470px' }}><DizzyStars x={960} y={380} t={t} /></g>
    </Sh>
  );
};

// S27: blood alcohol, 0.10%
export const S27: React.FC<ShotProps> = ({ t, len, f }) => {
  const p = at(t, 6, 50);
  return (
    <Sh t={t} len={len} f={f} a={[960, 540, 1.0]} b={[960, 540, 1.06]}>
      <Schematic t={t + 100} id="s27" />
      <Mono x={960} y={330} text="24 H AWAKE" size={44} />
      <Mono x={960} y={400} text="BEHAVES LIKE" size={36} color="#9FB0D8" />
      <CountUp x={960} y={640} t={t - 4} to={0.1} dur={44} size={150} color="#FF8A3D" suffix="%" format={(v) => v.toFixed(2)} />
      <Mono x={960} y={720} text="BLOOD ALCOHOL" size={40} />
      <rect x={720} y={800} width={480} height={34} rx={17} fill="#16172B" stroke="#8FA0C8" strokeWidth={4} />
      <rect x={724} y={804} width={472 * p} height={26} rx={13} fill="#FF8A3D" />
    </Sh>
  );
};

// S28: zero drinks
export const S28: React.FC<ShotProps> = ({ t, len, f }) => {
  const pose = act(t, { x: 960, y: 712, yaw: 0.3, look: 0.5, headTilt: 6 }, [{ f: 30, p: { headTilt: -8 } }], [[0, 'dizzy']]);
  return (
    <Sh t={t} len={len} f={f} a={[960, 600, 1.55]} b={[960, 590, 1.75]} over={<Tag x={960} y={330} t={t - 10} text="0 DRINKS" mark="x" markT={12} w={230} />}>
      <Study t={t + 160} id="s28" night />
      <Hero look={PIP} pose={pose} rimId="rimR" shadow={0} />
      <Desk x0={600} x1={1320} y={700} laptop={false} />
    </Sh>
  );
};

// S29: scientists rush Pip into the laboratory
export const S29: React.FC<ShotProps> = ({ t, len, f }) => {
  const k = at(t, 0, 54);
  const x = kf(t, [[0, 520], [54, 1000]]);
  const walk = (ph: number) => Math.sin(ph) * 28;
  const hero = (look: any, px: number, yaw: number, face: Pose['expr']) => (
    <Hero look={look} pose={act(t, { x: px, y: 712, yaw, armL: { a: walk(t / 3), b: -10 }, armR: { a: -walk(t / 3), b: -10 }, legL: { a: -walk(t / 3), b: 0 }, legR: { a: walk(t / 3), b: 0 } }, [], [[0, face]])} rimId="rimR" shadow={0} />
  );
  return (
    <Sh t={t} len={len} f={f} a={[960, 600, 0.95]} b={[980, 600, 1.1]}>
      <Study t={t + 200} id="s29" veil={0.3} />
      {hero(SUIT, x - 220, 0.7, 'neutral')}
      {hero(PIP, x, 0.7, 'worried')}
      {hero(SUIT, x + 230, 0.7, 'neutral')}
    </Sh>
  );
};

// S30: the scan
export const S30: React.FC<ShotProps> = ({ t, len, f }) => {
  const sy = 330 + ((t * 9) % 440);
  return (
    <Sh t={t} len={len} f={f} a={[960, 540, 1.0]} b={[960, 540, 1.1]}>
      <Schematic t={t + 130} id="s30" />
      <Brain x={960} y={560} s={1.5} col="#2B6A8A" glow={0.7} />
      <rect x={640} y={sy} width={640} height={8} fill="#7FD4FF" opacity={0.9} style={{ filter: 'drop-shadow(0 0 12px #7FD4FF)' }} />
      <rect x={640} y={sy - 90} width={640} height={90} fill="#7FD4FF" opacity={0.1} />
      <Mono x={960} y={260} text="SCANNING" size={44} color="#7FD4FF" />
    </Sh>
  );
};

// S31: the scientist is terrified
export const S31: React.FC<ShotProps> = ({ t, len, f }) => {
  const pose = act(t, { x: 960, y: 712, yaw: 0.15, headTilt: 0 }, [{ f: 10, p: { headTilt: -5 } }], [[0, 'neutral'], [8, 'shock']]);
  return (
    <Sh t={t} len={len} f={f} a={[960, 548, 3.3]} b={[960, 548, 3.8]}>
      <Study t={t + 230} id="s31" veil={0.5} />
      <Hero look={SUIT} pose={pose} rimId="rimRed" shadow={0} />
      <Glow x={960} y={560} r={500} o={0.18} />
    </Sh>
  );
};

// S32: during sleep the brain cleans itself
export const S32: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[960, 540, 1.0]} b={[960, 540, 1.08]}>
    <Schematic t={t + 150} id="s32" />
    <Brain x={960} y={540} s={1.45} col="#F29AB0" glow={1} />
    {Array.from({ length: 14 }).map((_, i) => {
      const p = ((t / 50 + i / 14) % 1);
      const a = rnd(3, i) * Math.PI * 2;
      return <circle key={i} cx={960 + Math.cos(a) * (60 + p * 330)} cy={540 + Math.sin(a) * (50 + p * 300)} r={10 * (1 - p) + 3} fill="#7FD4FF" opacity={1 - p} />;
    })}
    <Mono x={960} y={260} text="SLEEP = CLEANUP" size={42} color="#7FD4FF" />
    <Zzz x={1130} y={380} t={t} s={1.8} />
  </Sh>
);

// S33: in mice, ten times harder
export const S33: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[960, 540, 1.0]} b={[960, 540, 1.06]}>
    <Schematic t={t + 180} id="s33" />
    <Mouse x={960} y={330} s={1.1} asleep />
    <Mono x={960} y={420} text="IN MICE" size={40} />
    <rect x={720} y={560} width={480 * 0.1} height={60} fill="#8FA0C8" />
    <Mono x={720} y={545} text="AWAKE" size={30} anchor="start" color="#9FB0D8" />
    <rect x={720} y={700} width={480 * at(t, 14, 40)} height={60} fill="#7FD4FF" style={{ filter: 'drop-shadow(0 0 10px #7FD4FF)' }} />
    <Mono x={720} y={685} text="ASLEEP" size={30} anchor="start" color="#7FD4FF" />
    <BigNum x={960} y={930} text="~10x" size={170} color="#FFE27A" o={at(t, 30, 38)} s={backOut(at(t, 30, 40))} />
  </Sh>
);

// S34: without sleep the waste builds up
export const S34: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[960, 540, 1.0]} b={[960, 540, 1.1]}>
    <Schematic t={t + 200} id="s34" />
    <Brain x={960} y={540} s={1.45} col="#B77A98" dim={0.2} />
    {Array.from({ length: 40 }).map((_, i) => {
      const show = at(t, i * 0.7, i * 0.7 + 6);
      const a = rnd(5, i) * Math.PI * 2, r = 40 + rnd(6, i) * 190;
      return <circle key={i} cx={960 + Math.cos(a) * r * 1.05} cy={540 + Math.sin(a) * r * 0.75} r={14 * show} fill="#7A4A2A" stroke="#1A1230" strokeWidth={3} opacity={show} />;
    })}
    <Mono x={960} y={260} text="WASTE BUILDING UP" size={40} color="#FF8A3D" />
  </Sh>
);

// S35: day four, a blank at the name line
export const S35: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[960, 540, 1.0]} b={[960, 540, 1.1]}>
    <Tabletop edge={1000} wood="#7A5C42" grain="#6A4C36" lip="#5E4430" floor="#2A2230" floorLines="#201A26" />
    <LightVeil id="s35v" lights={[[960, 500, 560]]} o={0.5} />
    <Glow x={960} y={430} r={520} o={0.3} />
    <Paper x={960} y={520} w={420} rot={-3} done={false} fill={0} />
    <g transform="rotate(-3 960 520)">
      <text x={780} y={420} fontFamily={FONT.hand} fontWeight={700} fontSize={64} fill="#2A2A44">NAME:</text>
      <path d={`M 780 460 q 30 -30 60 0 t 60 0 t 60 0 t 60 0 t 60 0`} stroke="#2A2A44" strokeWidth={6} fill="none" strokeDasharray={600} strokeDashoffset={600 * (1 - at(t, 6, 40))} />
      <text x={1040} y={470} fontFamily={FONT.hand} fontWeight={700} fontSize={96} fill="#E0483C" opacity={at(t, 40, 46)}>?</text>
    </g>
    <FloatLabel x={1120} y={380} t={t - 40} text="DAY 4" size={64} color="#FFB36B" />
  </Sh>
);

// S36: Pip can't spell it
export const S36: React.FC<ShotProps> = ({ t, len, f }) => {
  const pose = act(t, { x: 960, y: 712, yaw: 0.2, headTilt: 0, look: -0.3 }, [{ f: 20, p: { headTilt: -8 } }], [[0, 'worried'], [16, 'shock']]);
  return (
    <Sh t={t} len={len} f={f} a={[960, 548, 3.2]} b={[960, 548, 3.7]}>
      <Study t={t + 260} id="s36" night />
      <Hero look={PIP} pose={pose} rimId="rimR" shadow={0} />
      <Desk x0={600} x1={1320} y={700} laptop={false} />
      <g transform="scale(0.45)" style={{ transformOrigin: '960px 470px' }}><FocusRings x={960} y={400} t={t - 6} /></g>
    </Sh>
  );
};

// S37: the doctors point to the one record
export const S37: React.FC<ShotProps> = ({ t, len, f }) => {
  const pose = act(t, { x: 820, y: 712, yaw: 0.6, look: 0.8, armR: { a: 20, b: -8 } }, [{ f: 8, p: { armR: { a: 100, b: 0 }, handR: 'point' }, ease: easeOut }], [[0, 'neutral']]);
  return (
    <Sh t={t} len={len} f={f} a={[1000, 600, 1.35]} b={[1010, 600, 1.55]}>
      <Study t={t + 300} id="s37" veil={0.34} />
      <Hero look={SUIT} pose={{ ...pose, handR: t >= 8 ? 'point' : 'open' }} rimId="rimR" shadow={0} />
      <g>
        <rect x={1000} y={480} width={280} height={190} rx={8} fill="#E8E4D8" stroke="#2B2F3A" strokeWidth={8} />
        <path d="M 1020 640 L 1070 600 L 1110 620 L 1160 540 L 1200 560 L 1260 500" stroke="#E0483C" strokeWidth={8} fill="none" strokeLinejoin="round" />
      </g>
    </Sh>
  );
};

// S38: 1964, 17 years old, 11 days. Day three lights red.
export const S38: React.FC<ShotProps> = ({ t, len, f }) => (
  <Sh t={t} len={len} f={f} a={[960, 540, 1.0]} b={[960, 540, 1.06]}>
    <Schematic t={t + 250} id="s38" />
    <BigNum x={960} y={350} text="1964" size={170} color="#F6EFE3" />
    <Mono x={960} y={430} text="17 YEARS OLD" size={40} color="#9FB0D8" />
    {Array.from({ length: 11 }).map((_, i) => {
      const on = t > 22 + i * 9;
      const red = i >= 2 && t > 22 + 2 * 9 + 60;
      return <rect key={i} x={700 + i * 48} y={650} width={38} height={90} rx={6} fill={red ? '#FF5A5A' : on ? '#FFE27A' : '#2A2F4A'} stroke="#8FA0C8" strokeWidth={3} />;
    })}
    <Mono x={960} y={800} text="11 DAYS AWAKE" size={46} color="#FFE27A" />
    <Mono x={960} y={870} text="DAY 3: MEMORY FAILS" size={34} color="#FF5A5A" o={at(t, 100, 112)} />
  </Sh>
);

// S40: then he slept for 14 hours
export const S40: React.FC<ShotProps> = ({ t, len, f }) => {
  const pose = act(t, { x: BS.x, y: BS.y, scale: BS.scale, yaw: 0.15, blink: 1, headTilt: 14 }, [], [[0, 'happy']]);
  return (
    <Sh t={t} len={len} f={f} a={[BS.x + 60, BS.y - 40, 1.4]} b={[BS.x + 40, BS.y - 60, 1.7]} over={<CountUp x={960} y={900} t={t - 6} to={14} dur={80} size={160} color="#6BF2A0" suffix=" h" />}>
      <Bedroom t={t + 400} id="b40" duvet={false} crossed={3} clock="03:00" />
      <Hero look={PIP} pose={pose} rimId="rimR" shadow={0} />
      <BedDuvet />
      <Zzz x={BS.x + 80} y={BS.y - 200 * BS.scale} t={t} s={BS.scale * 1.6} />
    </Sh>
  );
};
