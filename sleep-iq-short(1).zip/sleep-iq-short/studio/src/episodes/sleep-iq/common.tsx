import React from 'react';
import {
  Hero, Pose, basePose, poseAt, faceAt, kf, clamp, easeOut, backOut, rnd, settle, camT, LOOKS, FONT, ShotProps, Glow,
} from '../../engine';

export const PIP = LOOKS.pipHood;
export const lin = (x: number) => x;
export type Cam = [number, number, number];

// ---------- the IQ readout: always on screen, red flash and a pop when it drops (times = the spoken numbers) ----------
const IQS: [number, number][] = [[0, 100], [17.55, 90], [22.3, 80], [26.15, 70]];
export const Hud: React.FC<{ f: number; iq?: number; label?: string }> = ({ f, iq, label = 'IQ' }) => {
  const s = f / 30;
  let v = 100, at = 0;
  for (const [a, n] of IQS) if (s >= a) { v = n; at = a; }
  const val = iq ?? v;
  const d = iq === undefined ? (s - at) * 30 : 99;
  const hit = at > 0 && d < 16;
  const pop = hit ? 1 + 0.35 * Math.sin((d / 16) * Math.PI) : 1;
  const col = hit ? '#FF5A5A' : val <= 70 ? '#FFB36B' : '#FFE27A';
  const o = clamp((s - 3.7) / 0.4);
  return (
    <g transform="translate(960 104)" opacity={o}>
      <rect x={-118} y={-44} width={236} height={88} rx={44} fill="#0E0C1E" opacity={0.72} stroke={col} strokeWidth={3} />
      <text x={-86} y={14} fontFamily={FONT.ui} fontSize={30} fill="#F6EFE3" opacity={0.8}>{label}</text>
      <g transform={`translate(54 0) scale(${pop})`}>
        <text textAnchor="middle" y={22} fontFamily={FONT.title} fontWeight={800} fontSize={66} fill={col} stroke="#1A1230" strokeWidth={6} paintOrder="stroke">{val}</text>
      </g>
    </g>
  );
};

// ---------- the shot wrapper: camera a -> b over the shot, the IQ readout on top ----------
export const Sh: React.FC<{ t: number; len: number; f: number; a: Cam; b?: Cam; hud?: boolean; over?: React.ReactNode; children: React.ReactNode }> = ({ t, len, f, a, b, hud = true, over, children }) => {
  const e = b ?? a;
  return (
    <>
      <g transform={camT(kf(t, [[0, a[0]], [len, e[0]]], lin), kf(t, [[0, a[1]], [len, e[1]]], lin), kf(t, [[0, a[2]], [len, e[2]]], lin))}>{children}</g>
      {over}
      {hud ? <Hud f={f} /> : null}
    </>
  );
};

type Keys = Parameters<typeof poseAt>[1];
type Faces = [number, Pose['expr']][];
export const act = (t: number, base: Partial<Pose>, keys: Keys = [], faces: Faces = [[0, 'neutral']]): Pose => ({
  ...poseAt(t, [{ f: 0, p: base }, ...keys]),
  ...faceAt(t, faces),
});

// ---------- a vertical title card (the engine's is one wide line) ----------
export const VTitle: React.FC<{ t: number }> = ({ t }) => {
  const pop = (d: number) => backOut(clamp((t - d) / 9));
  const line = (txt: string, y: number, size: number, fill: string, d: number, w = 700) => (
    <g transform={`translate(960 ${y}) scale(${pop(d)})`}>
      <text textAnchor="middle" fontFamily={FONT.title} fontWeight={size > 100 ? 800 : 700} fontSize={size} fill={fill} stroke="#1A1230" strokeWidth={size > 100 ? 14 : 9} paintOrder="stroke" style={size > 100 ? { filter: 'drop-shadow(0 0 20px rgba(255,138,61,0.6))' } : undefined} textLength={w > 0 ? undefined : undefined}>{txt}</text>
    </g>
  );
  const pulse = t > 40 ? 1 + 0.06 * Math.sin((t - 40) / 6) : 1;
  return (
    <g>
      {line('WHAT IF EVERY NIGHT', 170, 40, '#F6EFE3', 2)}
      {line('YOU LOST', 226, 52, '#F6EFE3', 6)}
      <g transform={`translate(0 ${pulse > 1 ? 0 : 0})`}>{line('10 IQ', 380, 168 * pulse, '#FFE27A', 12)}</g>
      {line('POINTS?', 470, 92, '#FF8A3D', 17)}
    </g>
  );
};

// ---------- small props in the kit's style ----------
const sh = (x: number, y: number, rx: number) => <ellipse cx={x} cy={y} rx={rx} ry={rx * 0.16} fill="#000" opacity={0.3} />;

export const Cake: React.FC<{ x: number; y: number; s?: number; flame?: number }> = ({ x, y, s = 1, flame = 0 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    {sh(0, 4, 120)}
    <rect x={-100} y={-60} width={200} height={62} rx={8} fill="#E8B4C0" />
    <rect x={-100} y={-60} width={200} height={14} rx={7} fill="#FFF3F5" />
    <rect x={-84} y={-112} width={168} height={54} rx={8} fill="#D98BA0" />
    <rect x={-84} y={-112} width={168} height={12} rx={6} fill="#FFF3F5" />
    {[-44, 0, 44].map((cx, i) => (
      <g key={i}>
        <rect x={cx - 5} y={-150} width={10} height={40} fill={['#7FD4FF', '#FFE27A', '#B7E4A0'][i]} />
        <path d={`M ${cx} ${-176 - 6 * Math.sin(flame + i)} Q ${cx + 10} ${-160} ${cx} ${-152} Q ${cx - 10} ${-160} ${cx} ${-176 - 6 * Math.sin(flame + i)} Z`} fill="#FFB347" />
      </g>
    ))}
  </g>
);

export const Keys: React.FC<{ x: number; y: number; s?: number; rot?: number }> = ({ x, y, s = 1, rot = 0 }) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
    <circle cx={0} cy={0} r={26} fill="none" stroke="#B8BFC9" strokeWidth={8} />
    <rect x={20} y={-9} width={86} height={18} rx={4} fill="#D8DEE6" />
    <rect x={78} y={9} width={9} height={14} fill="#D8DEE6" />
    <rect x={95} y={9} width={9} height={20} fill="#D8DEE6" />
    <rect x={-6} y={22} width={14} height={50} rx={4} fill="#E9C46A" />
  </g>
);

export const Can: React.FC<{ x: number; y: number; s?: number; col?: string; tilt?: number }> = ({ x, y, s = 1, col = '#46C28A', tilt = 0 }) => (
  <g transform={`translate(${x} ${y}) rotate(${tilt}) scale(${s})`}>
    {sh(0, 0, 44)}
    <rect x={-34} y={-130} width={68} height={130} rx={10} fill={col} />
    <rect x={-34} y={-130} width={68} height={16} rx={8} fill="#D8DEE6" />
    <rect x={-34} y={-70} width={68} height={22} fill="#1A1230" opacity={0.35} />
    <path d="M 6 -112 L -10 -78 L 2 -78 L -6 -50 L 16 -90 L 4 -90 Z" fill="#FFE27A" />
    <rect x={-26} y={-124} width={8} height={112} rx={4} fill="#fff" opacity={0.25} />
  </g>
);

export const Brain: React.FC<{ x: number; y: number; s?: number; col?: string; glow?: number; dim?: number }> = ({ x, y, s = 1, col = '#F29AB0', glow = 0, dim = 0 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={1 - 0.6 * dim}>
    {glow > 0 ? <circle r={230} fill="#7FD4FF" opacity={0.18 * glow} /> : null}
    <path d="M -150 20 C -190 -40 -150 -120 -80 -120 C -60 -170 20 -170 50 -125 C 120 -150 190 -90 160 -20 C 195 30 150 110 90 100 C 60 140 -20 140 -50 105 C -110 125 -170 85 -150 20 Z" fill={col} stroke="#1A1230" strokeWidth={8} strokeLinejoin="round" />
    <g fill="none" stroke="#1A1230" strokeWidth={6} strokeLinecap="round" opacity={0.55}>
      <path d="M -90 -70 C -60 -40 -90 0 -50 20" />
      <path d="M 10 -120 C 30 -80 -10 -60 20 -20 C 40 10 10 40 40 80" />
      <path d="M 100 -80 C 80 -40 120 -20 100 20" />
      <path d="M -120 40 C -90 50 -70 40 -50 70" />
    </g>
  </g>
);

export const Mouse: React.FC<{ x: number; y: number; s?: number; asleep?: boolean }> = ({ x, y, s = 1, asleep = true }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    {sh(0, 4, 90)}
    <path d="M 70 -10 C 150 -10 170 -70 120 -90" stroke="#E9B6B6" strokeWidth={8} fill="none" strokeLinecap="round" />
    <ellipse cx={0} cy={-34} rx={80} ry={42} fill="#C9C3D4" />
    <ellipse cx={-62} cy={-44} rx={36} ry={30} fill="#C9C3D4" />
    <circle cx={-48} cy={-76} r={20} fill="#F2B8C6" stroke="#9A93A8" strokeWidth={4} />
    <circle cx={-100} cy={-38} r={7} fill="#F29AB0" />
    {asleep ? <path d="M -80 -54 Q -72 -48 -64 -54" stroke="#1A1230" strokeWidth={4} fill="none" strokeLinecap="round" /> : <circle cx={-72} cy={-54} r={5} fill="#1A1230" />}
  </g>
);

export const Zzz: React.FC<{ x: number; y: number; t: number; s?: number }> = ({ x, y, t, s = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    {[0, 1, 2].map((i) => {
      const p = ((t / 60 + i / 3) % 1);
      return <text key={i} x={p * 40 + i * 14} y={-p * 90} fontFamily={FONT.hand} fontWeight={700} fontSize={34 + i * 10} fill="#CFE0FF" opacity={Math.sin(p * Math.PI)}>Z</text>;
    })}
  </g>
);

export const Monitor: React.FC<{ x: number; y: number; t: number; s?: number }> = ({ x, y, t, s = 1 }) => {
  const pts = Array.from({ length: 40 }).map((_, i) => {
    const ph = ((i * 5 + t * 3) % 100);
    const yy = ph > 44 && ph < 48 ? -34 : ph >= 48 && ph < 52 ? 26 : ph >= 52 && ph < 56 ? -6 : 0;
    return `${i === 0 ? 'M' : 'L'} ${-110 + i * 5.6} ${yy}`;
  }).join(' ');
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <rect x={-140} y={-80} width={280} height={160} rx={14} fill="#10131C" stroke="#3A4256" strokeWidth={6} />
      <path d={pts} stroke="#6BF2A0" strokeWidth={5} fill="none" strokeLinejoin="round" style={{ filter: 'drop-shadow(0 0 8px #6BF2A0)' }} />
      <circle cx={104} cy={-52} r={7} fill="#6BF2A0" opacity={0.5 + 0.5 * Math.sin(t / 5)} />
    </g>
  );
};

export const BigNum: React.FC<{ x: number; y: number; text: string; size?: number; color?: string; o?: number; s?: number }> = ({ x, y, text, size = 200, color = '#FFE27A', o = 1, s = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}>
    <text textAnchor="middle" fontFamily={FONT.title} fontWeight={800} fontSize={size} fill={color} stroke="#1A1230" strokeWidth={size / 9} paintOrder="stroke" style={{ filter: `drop-shadow(0 0 ${size / 7}px ${color}88)` }}>{text}</text>
  </g>
);

export const Mono: React.FC<{ x: number; y: number; text: string; size?: number; color?: string; o?: number; anchor?: 'start' | 'middle' | 'end' }> = ({ x, y, text, size = 34, color = '#F6EFE3', o = 1, anchor = 'middle' }) => (
  <text x={x} y={y} textAnchor={anchor} fontFamily={FONT.ui} fontSize={size} fill={color} opacity={o} letterSpacing={2}>{text}</text>
);

/** A dark window frame to shoot through: foreground, blurred a touch, with a lit pane. */
export const WindowFG: React.FC<{ x: number; y: number }> = ({ x, y }) => (
  <g>
    <path d={`M ${x - 420} ${y - 700} H ${x + 420} V ${y + 700} H ${x - 420} Z M ${x - 230} ${y - 520} V ${y + 520} H ${x + 230} V ${y - 520} Z`} fillRule="evenodd" fill="#0A0A12" />
    <rect x={x - 6} y={y - 520} width={12} height={1040} fill="#0A0A12" />
    <rect x={x - 230} y={y - 12} width={460} height={12} fill="#0A0A12" />
  </g>
);
export { Pose, basePose, poseAt, faceAt, kf, clamp, easeOut, backOut, rnd, settle, camT, FONT, Glow };
export type { ShotProps };
