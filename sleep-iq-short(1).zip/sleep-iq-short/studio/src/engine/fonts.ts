import { loadFont } from '@remotion/fonts';
import { staticFile } from 'remotion';
import { STUDIO } from '../studio.config';

// Offline build: the same three OFL faces, served from public/fonts (Fontsource files) instead of Google Fonts.
const L = (family: string, file: string, weight: string) =>
  loadFont({ family, url: staticFile(`fonts/${file}.woff2`), weight });
L('Bricolage Grotesque', 'bricolage-grotesque-latin-600-normal', '600');
L('Bricolage Grotesque', 'bricolage-grotesque-latin-700-normal', '700');
L('Bricolage Grotesque', 'bricolage-grotesque-latin-800-normal', '800');
L('Fragment Mono', 'fragment-mono-latin-400-normal', '400');
L('Kalam', 'kalam-latin-400-normal', '400');
L('Kalam', 'kalam-latin-700-normal', '700');
if (STUDIO.titleFont) loadFont({ family: STUDIO.titleFont.family, url: staticFile(STUDIO.titleFont.file), weight: STUDIO.titleFont.weight });

export const FONT = {
  title: STUDIO.titleFont ? STUDIO.titleFont.family : 'Bricolage Grotesque',
  ui: 'Fragment Mono',
  hand: 'Kalam',
};
